﻿using $safeprojectname$.Entidades;

namespace $safeprojectname$.Interfaces
{
    public interface IExemploRepoitorio : IGenericoRepositorio<Exemplo>
    {
    }
}
