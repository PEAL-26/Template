﻿using $safeprojectname$.Shared.ViewModels;
using System;
using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.ViewModels
{
    public class ExemploViewModel : BaseViewModel
    {
    
    }
}
