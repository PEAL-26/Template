﻿using $safeprojectname$.ViewModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace $safeprojectname$.Interfaces
{
    public interface IExemploApp : IGenericaApp<ExemploViewModel>
    {
    }
}
