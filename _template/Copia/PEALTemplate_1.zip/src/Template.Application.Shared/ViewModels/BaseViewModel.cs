﻿using Flunt.Notifications;

namespace $safeprojectname$.ViewModels
{
    public class BaseViewModel : Notifiable<Notification>
    {
    }
}
