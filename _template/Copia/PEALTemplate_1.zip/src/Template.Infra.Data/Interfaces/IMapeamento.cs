﻿namespace $safeprojectname$.Interfaces
{
    interface IMapeamento
    {
    }
}
