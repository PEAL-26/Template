﻿using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$.Configuracoes
{
    public static class ConfiguracaoSeeds
    {
        public static void AplicarConfiguracao(ModelBuilder modelBuilder)
        {
          
        }
    }
}
