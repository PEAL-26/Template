﻿using $safeprojectname$.Entidades;

namespace $safeprojectname$.Interfaces
{
    public interface IExemploServico : IGenericoServico<Exemplo>
    {
    }
}
